/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
    domains: ['getbyweb.com', 'cdn2.arogga.com', 'www.jiomart.com'],
  },
};

export default nextConfig;
