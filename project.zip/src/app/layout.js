import Navbar from '@/components/Navbar';
import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'JG Pharmacy - Your One Stop HealthCare Solutions',
  description: 'Discover amazing destinations with TravelEase',
  icons: {
    icon: '/e-commerce-logo.jpeg', // can be .png, .ico, .svg, etc.
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel='icon' type='image/webp'  href='/napa=1.webp' />
      </head>
      <body className="min-h-screen bg-gray-50">
        {children}
      </body>
    </html>
  );
}
