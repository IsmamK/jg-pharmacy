"use client";

import { useState, useRef, useEffect } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";

const ProductSection = ({
  id,
  productName,
  showSeeAll = true,
  showRating = true,
  showDiscount = true,
  showDelivery = true,
  showOriginalPrice = true,
}) => {
  const router = useRouter();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isClient, setIsClient] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // Handle product click
  const handleProductClick = (category,slug) => {
    router.push(`/${category}/individualsProduct/${slug}/`);
  };

  //collection api
  const sampleData = {
    section: {
      title: "Top Deals of the Week",
      subtitle: "Don't miss out on these exclusive offers!",
    },
    cards: [
      {
        id: 1,
        category : 'Hardwire',
        slug : 'wireless-earphone',
        offer: "50% OFF",
        hours: "Ends in 12h",
        image:
          "https://getbyweb.com/wp-content/uploads/2024/09/Fogg-Fine-Bay-Breeze.webp",
        cardName: "Wireless Headphones",
        productPrice: 120.0,
        discountPrice: 60.0,
        ratings: 4.5,
      },
      {
        id: 2,
        category : 'Hardwire',
        slug : 'Organic-Green-Tea',
        offer: "Buy 1 Get 1 Free",
        hours: "Ends in 6h",
        image:
          "https://cdn2.arogga.com/eyJidWNrZXQiOiJhcm9nZ2EiLCJrZXkiOiJQcm9kdWN0LXBfaW1hZ2VzXC82NTU3M1wvNjU1NzMtMTY2OTM1NDk5OGI4MzliZTY1ZWQ2M2IyOWNhNjE4M2QxYzQ4MDlhYTk5LWpqNWVnYy53ZWJwIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjozMDAsImhlaWdodCI6MzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
        cardName: "Organic Green Tea",
        productPrice: 25.0,
        discountPrice: 25.0,
        ratings: 4.8,
      },
      {
        id: 3,
        category : 'Hardwire',
        slug : 'Smart-LED-Bulb',
        offer: "30% OFF",
        hours: "Ends in 3h",
        image:
          "https://cdn2.arogga.com/eyJidWNrZXQiOiJhcm9nZ2EiLCJrZXkiOiJQcm9kdWN0LXBfaW1hZ2VzXC82OTUzMFwvNjk1MzAtTGl2b24tQW50aS1IYWlyZmFsbC1Qcm90ZWluLVNoYW1wb28tMzAwbWwtRlJFRS1QYXJhY2h1dGUtU2tpblB1cmUtU2tpbi1Mb3Rpb24tTmF0dXJhbC1XaGl0ZS0xMDBtbC03N250dnEucG5nIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjozMDAsImhlaWdodCI6MzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
        cardName: "Smart LED Bulb",
        productPrice: 40.0,
        discountPrice: 28.0,
        ratings: 4.2,
      },
      {
        id: 4,
        category : 'Hardwire',
        slug : 'Fitness-Tracker-Band',
        offer: "20% OFF",
        hours: "Ends in 24h",
        image:
          "https://cdn2.arogga.com/eyJidWNrZXQiOiJhcm9nZ2EiLCJrZXkiOiJQcm9kdWN0LXBfaW1hZ2VzXC82ODE5OFwvNjgxOTgtNzFWdEVRemtES0wtYWN4OWt2LmpwZWciLCJlZGl0cyI6eyJyZXNpemUiOnsid2lkdGgiOjMwMCwiaGVpZ2h0IjozMDAsImZpdCI6Im91dHNpZGUifX19",
        cardName: "Fitness Tracker Band",
        productPrice: 75.0,
        discountPrice: 60.0,
        ratings: 4.6,
      },
      {
        id: 5,
        category : 'Hardwire',
        slug : 'Bluetooth-Speaker',
        offer: "60% OFF",
        hours: "Ends in 2h",
        image:
          "https://www.jiomart.com/images/product/original/rvtjpeg3uk/fogg-fine-breeze-no-gas-mild-fragrance-body-spray-for-women-everyday-deodorant-120ml-product-images-orvtjpeg3uk-p603975624-4-202308191228.jpg?im=Resize=(420,420)",
        cardName: "Bluetooth Speaker",
        productPrice: 100.0,
        discountPrice: 40.0,
        ratings: 4.7,
      },
      {
        id: 6,
        category : 'Hardwire',
        slug : 'Laptop-Stand',
        offer: "25% OFF",
        hours: "Ends in 8h",
        image:
          "https://cdn2.arogga.com/eyJidWNrZXQiOiJhcm9nZ2EiLCJrZXkiOiJQcm9kdWN0LXBfaW1hZ2VzXC83ODQzMlwvNzg0MzItMTcxODI1NjU4ODNhZTVkYWQzMDM1MGVlN2FmYjI2MTk5ZGExYTZmNzdhLWl4aWx4My5qcGVnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjozMDAsImhlaWdodCI6MzAwLCJmaXQiOiJvdXRzaWRlIn19fQ==",
        cardName: "Laptop Stand",
        productPrice: 50.0,
        discountPrice: 37.5,
        ratings: 4.3,
      },
      {
        id: 7,
        category : 'Hardwire',
        slug : 'Portable-Charger',
        offer: "15% OFF",
        hours: "Ends in 18h",
        image:
          "https://cdn2.arogga.com/eyJidWNrZXQiOiJhcm9nZ2EiLCJrZXkiOiJQcm9kdWN0LXBfaW1hZ2VzXC83ODk3MVwvNzg5NzEtV2hhdHNBcHAtSW1hZ2UtMjAyNS0wMy0yNS1hdC0xNC0xYnF6MGkuanBlZyIsImVkaXRzIjp7InJlc2l6ZSI6eyJ3aWR0aCI6MzAwLCJoZWlnaHQiOjMwMCwiZml0Ijoib3V0c2lkZSJ9fX0=",
        cardName: "Portable Charger",
        productPrice: 60.0,
        discountPrice: 51.0,
        ratings: 4.4,
      },
    ],
  };

  useEffect(() => {
    setIsClient(true);
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const { section, cards: products } = sampleData;
  const productsPerPage = isMobile ? 3 : 6;
  const totalPages = Math.ceil(products.length / productsPerPage);
  const visibleProducts = products.slice(currentIndex, currentIndex + productsPerPage);

  const handleNext = () => {
    if (currentIndex + productsPerPage < products.length) {
      setCurrentIndex(prev => prev + productsPerPage);
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - productsPerPage);
    }
  };

  if (!isClient) {
    return null;
  }

  // Design 1 - Blue/Indigo theme
  if (id === 1) {
    return (
      <div className="px-4 md:px-8 py-8 md:py-12 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6 md:mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800">
              {section.title}
            </h2>
            {showSeeAll && (
              <button className="text-blue-600 hover:text-blue-800 font-medium flex items-center text-sm md:text-base">
                See all
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 ml-1"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </button>
            )}
          </div>

          <div className="relative">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
              {visibleProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded-lg md:rounded-xl shadow-sm md:shadow-md overflow-hidden hover:shadow-md md:hover:shadow-lg transition-shadow duration-300 flex flex-col cursor-pointer"
                  onClick={() => handleProductClick(product.category, product.slug)}
                >
                  <div className="p-3 md:p-4 flex-grow">
                    <div className="relative h-32 md:h-40 rounded-lg mb-3 md:mb-4 overflow-hidden bg-gray-100 flex items-center justify-center">
                      <Image
                        src={product.image}
                        alt={product.cardName}
                        width={200}
                        height={200}
                        className="object-contain h-full w-full"
                        loading="lazy"
                        onError={(e) => {
                          e.target.src =
                            "https://via.placeholder.com/200x200?text=Product+Image";
                        }}
                      />
                    </div>
                    <div className="mb-2">
                      {showDiscount && product.offer && (
                        <span className="text-xs font-semibold bg-blue-100 text-blue-600 px-2 py-1 rounded">
                          {product.offer}
                        </span>
                      )}
                      {showDelivery && product.hours && (
                        <span className="text-xs text-gray-500 ml-2">
                          {product.hours}
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm font-medium text-gray-800 mb-1 line-clamp-1">
                      {product.cardName}
                    </h3>
                    {showRating && (
                      <div className="flex items-center mb-2">
                        {[...Array(5)].map((_, i) => (
                          <svg
                            key={i}
                            className={`w-3 h-3 md:w-4 md:h-4 ${
                              i < Math.floor(product.ratings)
                                ? "text-yellow-400"
                                : "text-gray-300"
                            }`}
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                        <span className="text-xs text-gray-500 ml-1">
                          ({product.ratings})
                        </span>
                      </div>
                    )}
                    <div className="flex items-center">
                      <span className="text-base md:text-lg font-bold text-gray-900">
                        ${product.discountPrice}
                      </span>
                      {showOriginalPrice && product.productPrice && (
                        <span className="text-xs md:text-sm text-gray-500 line-through ml-2">
                          ${product.productPrice}
                        </span>
                      )}
                    </div>
                  </div>
                  <button 
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 text-xs md:text-sm font-medium transition-colors duration-200"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Handle add to cart logic here
                    }}
                  >
                    ADD
                  </button>
                </div>
              ))}
            </div>

            {products.length > productsPerPage && (
              <>
                <button
                  onClick={handlePrev}
                  disabled={currentIndex === 0}
                  className={`absolute -left-4 md:-left-6 top-1/2 transform -translate-y-1/2 bg-white rounded-full w-8 h-8 md:w-12 md:h-12 flex items-center justify-center shadow-md hover:shadow-lg transition-shadow duration-200 hover:bg-blue-50 ${
                    currentIndex === 0 ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                  aria-label="Previous products"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 md:h-6 md:w-6 text-blue-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 19l-7-7 7-7"
                    />
                  </svg>
                </button>
                <button
                  onClick={handleNext}
                  disabled={currentIndex + productsPerPage >= products.length}
                  className={`absolute -right-4 md:-right-6 top-1/2 transform -translate-y-1/2 bg-white rounded-full w-8 h-8 md:w-12 md:h-12 flex items-center justify-center shadow-md hover:shadow-lg transition-shadow duration-200 hover:bg-blue-50 ${
                    currentIndex + productsPerPage >= products.length ? 'opacity-50 cursor-not-allowed' : ''
                  }`}
                  aria-label="Next products"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 md:h-6 md:w-6 text-blue-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 5l7 7-7 7"
                    />
                  </svg>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Design 2 - Orange/Amber theme
  if (id === 2) {
    return (
      <div className="px-4 md:px-8 py-8 md:py-12 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6 md:mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800">
              {section.title}
            </h2>
            <div className="flex space-x-2 md:space-x-4">
              <button
                onClick={handlePrev}
                disabled={currentIndex === 0}
                className={`p-1 md:p-2 rounded-full ${
                  currentIndex === 0
                    ? "bg-gray-200 text-gray-400"
                    : "bg-white text-amber-600 shadow-md hover:bg-amber-50"
                }`}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 md:h-6 md:w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 19l-7-7 7-7"
                  />
                </svg>
              </button>
              <button
                onClick={handleNext}
                disabled={currentIndex + productsPerPage >= products.length}
                className={`p-1 md:p-2 rounded-full ${
                  currentIndex + productsPerPage >= products.length
                    ? "bg-gray-200 text-gray-400"
                    : "bg-white text-amber-600 shadow-md hover:bg-amber-50"
                }`}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 md:h-6 md:w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </button>
            </div>
          </div>

          <div className="relative overflow-hidden">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
              {visibleProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded-lg md:rounded-xl shadow-sm md:shadow-md overflow-hidden hover:shadow-md md:hover:shadow-lg transition-shadow duration-300 h-full flex flex-col cursor-pointer"
                  onClick={() => handleProductClick(product.category, product.slug)}
                >
                  <div className="relative">
                    <div className="h-32 md:h-48 w-full bg-gray-100 flex items-center justify-center">
                      <Image
                        src={product.image}
                        alt={product.cardName}
                        width={300}
                        height={300}
                        className="object-contain h-full w-full"
                        onError={(e) => {
                          e.target.src =
                            "https://via.placeholder.com/200x200?text=Product+Image";
                        }}
                      />
                    </div>
                    {showDiscount && product.offer && (
                      <div className="absolute top-2 left-2 bg-amber-600 text-white text-xs font-bold px-2 py-1 rounded">
                        {product.offer}
                      </div>
                    )}
                  </div>
                  <div className="p-3 md:p-4 flex-grow flex flex-col">
                    {showDelivery && product.hours && (
                      <div className="text-xs text-amber-600 mb-1">
                        {product.hours}
                      </div>
                    )}
                    <h3 className="text-sm font-semibold text-gray-800 mb-2 line-clamp-1">
                      {product.cardName}
                    </h3>
                    {showRating && (
                      <div className="flex items-center mb-2">
                        {[...Array(5)].map((_, i) => (
                          <svg
                            key={i}
                            className={`w-3 h-3 md:w-4 md:h-4 ${
                              i < Math.floor(product.ratings)
                                ? "text-yellow-400"
                                : "text-gray-300"
                            }`}
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                        <span className="text-xs text-gray-500 ml-1">
                          ({product.ratings})
                        </span>
                      </div>
                    )}
                    <div className="mt-auto">
                      <div className="flex items-center">
                        {showOriginalPrice && product.productPrice && (
                          <span className="text-gray-500 text-xs md:text-sm line-through mr-2">
                            ${product.productPrice}
                          </span>
                        )}
                        <span className="text-base md:text-lg font-bold text-amber-600">
                          ${product.discountPrice}
                        </span>
                      </div>
                    </div>
                    <button 
                      className="mt-2 md:mt-3 w-full bg-amber-600 hover:bg-amber-700 text-white py-2 px-4 rounded-lg text-xs md:text-sm font-medium transition-colors duration-300"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle add to cart logic here
                      }}
                    >
                      ADD
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Design 3 - Green theme
  if (id === 3) {
    return (
      <div className="px-4 md:px-8 py-8 md:py-12 bg-gradient-to-r from-green-50 to-emerald-50">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6 md:mb-8">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800">
              {section.title}
            </h2>
            <div className="flex space-x-2 md:space-x-4">
              <button
                onClick={handlePrev}
                disabled={currentIndex === 0}
                className={`p-1 md:p-2 rounded-full ${
                  currentIndex === 0
                    ? "bg-gray-200 text-gray-400"
                    : "bg-white text-emerald-600 shadow-md hover:bg-emerald-50"
                }`}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 md:h-6 md:w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 19l-7-7 7-7"
                  />
                </svg>
              </button>
              <button
                onClick={handleNext}
                disabled={currentIndex + productsPerPage >= products.length}
                className={`p-1 md:p-2 rounded-full ${
                  currentIndex + productsPerPage >= products.length
                    ? "bg-gray-200 text-gray-400"
                    : "bg-white text-emerald-600 shadow-md hover:bg-emerald-50"
                }`}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5 md:h-6 md:w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </button>
            </div>
          </div>

          <div className="relative overflow-hidden">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6">
              {visibleProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white rounded-lg md:rounded-xl shadow-sm md:shadow-md overflow-hidden hover:shadow-md md:hover:shadow-lg transition-shadow duration-300 h-full flex flex-col border border-emerald-100 cursor-pointer"
                  onClick={() => handleProductClick(product.category, product.slug)}
                >
                  <div className="relative">
                    <div className="h-32 md:h-48 w-full bg-gray-100 flex items-center justify-center">
                      <Image
                        src={product.image}
                        alt={product.cardName}
                        width={300}
                        height={300}
                        className="object-contain h-full w-full"
                        onError={(e) => {
                          e.target.src =
                            "https://via.placeholder.com/200x200?text=Product+Image";
                        }}
                      />
                    </div>
                    {showDiscount && product.offer && (
                      <div className="absolute top-2 left-2 bg-emerald-600 text-white text-xs font-bold px-2 py-1 rounded">
                        {product.offer}
                      </div>
                    )}
                  </div>
                  <div className="p-3 md:p-4 flex-grow flex flex-col">
                    {showDelivery && product.hours && (
                      <div className="text-xs text-emerald-600 mb-1">
                        {product.hours}
                      </div>
                    )}
                    <h3 className="text-sm font-semibold text-gray-800 mb-2 line-clamp-1">
                      {product.cardName}
                    </h3>
                    {showRating && (
                      <div className="flex items-center mb-2">
                        {[...Array(5)].map((_, i) => (
                          <svg
                            key={i}
                            className={`w-3 h-3 md:w-4 md:h-4 ${
                              i < Math.floor(product.ratings)
                                ? "text-yellow-400"
                                : "text-gray-300"
                            }`}
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                        <span className="text-xs text-gray-500 ml-1">
                          ({product.ratings})
                        </span>
                      </div>
                    )}
                    <div className="mt-auto">
                      <div className="flex items-center">
                        {showOriginalPrice && product.productPrice && (
                          <span className="text-gray-500 text-xs md:text-sm line-through mr-2">
                            ${product.productPrice}
                          </span>
                        )}
                        <span className="text-base md:text-lg font-bold text-emerald-600">
                          ${product.discountPrice}
                        </span>
                      </div>
                    </div>
                    <button 
                      className="mt-2 md:mt-3 w-full bg-emerald-600 hover:bg-emerald-700 text-white py-2 px-4 rounded-lg text-xs md:text-sm font-medium transition-colors duration-300"
                      onClick={(e) => {
                        e.stopPropagation();
                        // Handle add to cart logic here
                      }}
                    >
                      ADD
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default ProductSection;